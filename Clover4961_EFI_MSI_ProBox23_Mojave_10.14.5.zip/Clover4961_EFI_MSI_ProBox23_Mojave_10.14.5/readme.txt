﻿Cover          v2.4k 4961
lilu           v1.3.6
AppleALC       v1.3.8
WhatEvergreen  v1.2.9

SMBIOS : iMac14,2

从苹果下载原版Mojave 10.14.5:

http://swcdn.apple.com/content/downloads/21/07/041-59913/m210y0lkn7bsiqsi98vfuyk08x2z4to1qk/BaseSystem.dmg
http://swcdn.apple.com/content/downloads/21/07/041-59913/m210y0lkn7bsiqsi98vfuyk08x2z4to1qk/BaseSystem.chunklist
http://swcdn.apple.com/content/downloads/21/07/041-59913/m210y0lkn7bsiqsi98vfuyk08x2z4to1qk/InstallInfo.plist
http://swcdn.apple.com/content/downloads/21/07/041-59913/m210y0lkn7bsiqsi98vfuyk08x2z4to1qk/InstallESDDmg.pkg
http://swcdn.apple.com/content/downloads/21/07/041-59913/m210y0lkn7bsiqsi98vfuyk08x2z4to1qk/AppleDiagnostics.dmg
http://swcdn.apple.com/content/downloads/21/07/041-59913/m210y0lkn7bsiqsi98vfuyk08x2z4to1qk/AppleDiagnostics.chunklist



参考：
https://www.insanelymac.com/forum/topic/329828-making-a-bootable-high-sierra-usb-installer-entirely-from-scratch-in-windows-or-linux-mint-without-access-to-mac-or-app-store-installerapp/

Apple's Regular Software Catalog
https://swscan.apple.com/content/catalogs/others/index-10.14-10.13-10.12-10.11-10.10-10.9-mountainlion-lion-snowleopard-leopard.merged-1.sucatalog.gz
